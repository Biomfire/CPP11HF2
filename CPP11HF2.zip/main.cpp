#include <iostream>
#include "GameManager.h"
int main() {
    GameManager gm;
    gm.GameLoop();
    return 0;
}